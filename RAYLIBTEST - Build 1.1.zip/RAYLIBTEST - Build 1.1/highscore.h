#ifndef HIGHSCORE_H
#define HIGHSCORE_H

void LoadHighScore(void);
void SaveHighScore(int score);
int GetHighScore(void);

#endif
