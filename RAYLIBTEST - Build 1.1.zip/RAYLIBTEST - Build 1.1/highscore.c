#include "highscore.h"
#include <stdio.h>

static int highScore = 0;

void LoadHighScore(void)
{
    FILE *file = fopen("highscore.dat", "r");

    if (file != NULL)
    {
        fscanf(file, "%d", &highScore);
        fclose(file);
    }
}

void SaveHighScore(int score)
{
    if (score > highScore)
    {
        highScore = score;

        FILE *file = fopen("highscore.dat", "w");

        if (file != NULL)
        {
            fprintf(file, "%d", highScore);
            fclose(file);
        }
    }
}

int GetHighScore(void)
{
    return highScore;
}
